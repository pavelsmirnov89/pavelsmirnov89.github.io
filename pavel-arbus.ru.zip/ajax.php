<?php 
$tpmonth;
$sdk;
$sdkprom;
$summsdk;
if(preg_replace("/[^0-9%]/", '',$_POST['promakcc'])=='5%'){
$sdkprom='5';
}else if(preg_replace("/[^0-9%]/", '',$_POST['promakcc'])=='2%'){
$sdkprom='2';
}else if(preg_replace("/[^0-9%]/", '',$_POST['promakcc'])=='20%'){
$sdkprom='20';
}else if(preg_replace("/[^0-9%]/", '',$_POST['promakcc'])=='50%'){
$sdkprom='50';
}
if($_POST['tarif']=='Эконом'){
$sdk='3';
}else if($_POST['tarif']=='Избранный'){
$sdk='5';	
}else if($_POST['tarif']=='Премиум'){
$sdk='7';	
}
if($_POST['fuel']=='Бензин'){
$tpmonth=500200*preg_replace("/[^0-9]/", '', $_POST['tonn'])-(500200*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdk/100+(500200*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdkprom/100));
$summsdk=500200*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdk/100+(500200*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdkprom/100);
}else if($_POST['fuel']=='Газ'){
$tpmonth=200100*preg_replace("/[^0-9]/", '', $_POST['tonn'])-(200100*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdk/100+(200100*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdkprom/100));
$summsdk=200100*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdk/100+(200100*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdkprom/100);
}else if($_POST['fuel']=='ДТ'){
$tpmonth=320700*preg_replace("/[^0-9]/", '', $_POST['tonn'])-(320700*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdk/100+(320700*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdkprom/100));
$summsdk=320700*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdk/100+(320700*preg_replace("/[^0-9]/", '', $_POST['tonn'])*$sdkprom/100);
}
echo 'Регион: '.$_POST['region'].';</br>';
echo 'Прокачка: '.$_POST['tonn'].';</br>';
echo 'Тип топлива: '.$_POST['fuel'].';</br>';
echo 'Бренд: '.$_POST['brend'].';</br>';
echo 'Дополнительные услуги: '.$_POST['dop_services'].';</br>';
echo 'Тариф: '.$_POST['tarif'].';</br>';
echo 'Промо-акция: '.$_POST['promakcc'].';</br>';
echo 'Стоимость топлива в месяц: '.number_format($tpmonth, 0, ',', ' ').' ₽;</br>';
echo 'Суммарная скидка %: '.($sdk+$sdkprom).'%;</br>';
echo 'Экономия в месяц: '.number_format($summsdk, 0, ',', ' ').' ₽;</br>';
echo 'Экономия в год: '.number_format(($summsdk*12), 0, ',', ' ').' ₽;</br>';
if($_POST['inn']!='' && $_POST['phone']!='' && $_POST['email']!='' && $_POST['obrn']=='1'){
if (preg_match("/^(?:[a-z0-9]+(?:[-_.]?[a-z0-9]+)?@[a-z0-9_.-]+(?:\.?[a-z0-9]+)?\.[a-z]{2,5})$/i", $_POST['email'])) {
   echo "<p style='color:#0f0;'>Адрес email указан корректно.</p>";
}else{
   echo "<p style='color:#f00;'>Адрес email указан не правильно.</p>";
}
}else{
if($_POST['inn']==''){
	echo '<style>.whitefon .form-control.inn{border:2px solid #f00;}</style>';
	echo "<p style='color:#f00;'>Вы не указали номер ИНН!</p>";
}
if($_POST['phone']==''){
	echo '<style>.whitefon .form-control.phone{border:2px solid #f00;}</style>';
	echo "<p style='color:#f00;'>Вы не указали телефон для связи!</p>";
}
if($_POST['email']==''){
	echo '<style>.whitefon .form-control.email{border:2px solid #f00;}</style>';
	echo "<p style='color:#f00;'>Вы не указали адресс email!</p>";
}
if($_POST['obrn']==''){
	echo '<style>.whitefon #obrn{border:2px solid #f00;border-radius:100%;}</style>';
	echo "<p style='color:#f00;'>Вы не дали согласие на обработку персональных данных!</p>";
}
}
 ?>