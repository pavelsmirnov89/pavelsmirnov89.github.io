$(document).ready(function(){
$('.akcse:nth-child(3)').addClass('active');
$.fn.setCursorPosition = function(pos) {
if ($(this).get(0).setSelectionRange) {
$(this).get(0).setSelectionRange(pos, pos);
} else if ($(this).get(0).createTextRange) {
var range = $(this).get(0).createTextRange();
range.collapse(true);
range.moveEnd('character', pos);
range.moveStart('character', pos);
range.select();
}
}
$('.tonn').text(parseInt($('.metka>span:last-child').text())*40/100+' тонн');	
$( ".liner" ).slider({
animate: "slow",
range: "min", 
slide: function( event, ui ) {
$('.tonn').text(parseInt($('.metka>span:last-child').text())*ui.value/100+' тонн');
if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())<100) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())<200) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())<150)){
$('.select select option:nth-child(1)').prop('selected',true);
$('.select select').trigger('change');
}else if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())>=100 && parseInt($('.tonn').text())<300) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())>=200 && parseInt($('.tonn').text())<=700) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())>=150 && parseInt($('.tonn').text())<=350)){
	$('.select select option:nth-child(2)').prop('selected',true);
	$('.select select').trigger('change');
}else if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())>=300) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())>=700) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())>=350)){
	$('.select select option:nth-child(3)').prop('selected',true);
	$('.select select').trigger('change');
}
},  
value: 40
});
$('#region').change(function(){
$('.metka>span:nth-child(2)').text($(this).val()/2+' тонн');
$('.metka>span:last-child').text($(this).val()+' тонн');
$( ".liner" ).slider({
animate: "slow",
range: "min", 
slide: function( event, ui ) {
$('.tonn').text(parseInt($('.metka>span:last-child').text())*ui.value/100+' тонн');
if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())<100) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())<200) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())<150)){
$('.select select option:nth-child(1)').prop('selected',true);
$('.select select').trigger('change');
}else if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())>=100 && parseInt($('.tonn').text())<300) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())>=200 && parseInt($('.tonn').text())<=700) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())>=150 && parseInt($('.tonn').text())<=350)){
	$('.select select option:nth-child(2)').prop('selected',true);
	$('.select select').trigger('change');
}else if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())>=300) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())>=700) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())>=350)){
	$('.select select option:nth-child(3)').prop('selected',true);
	$('.select select').trigger('change');
}
},  
value: 40
});
$('.tonn').text(parseInt($('.metka>span:last-child').text())*40/100+' тонн');	
if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())<100) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())<200) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())<150)){
$('.select select option:nth-child(1)').prop('selected',true);
$('.select select').trigger('change');
}else if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())>=100 && parseInt($('.tonn').text())<300) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())>=200 && parseInt($('.tonn').text())<=700) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())>=150 && parseInt($('.tonn').text())<=350)){
	$('.select select option:nth-child(2)').prop('selected',true);
	$('.select select').trigger('change');
}else if(($('.sweech_gs .active').text()=='Бензин' && parseInt($('.tonn').text())>=300) || ($('.sweech_gs .active').text()=='Газ' && parseInt($('.tonn').text())>=700) || ($('.sweech_gs .active').text()=='ДТ' && parseInt($('.tonn').text())>=350)){
	$('.select select option:nth-child(3)').prop('selected',true);
	$('.select select').trigger('change');
}
});
$('.sweech_gs>span').each(function(){
$(this).click(function(){
var brand=$(this).attr('date_gs');
$('.brands:not(.services) .img').removeClass('active');
$('.brands:not(.services)  .img').each(function(){
if($(this).attr('date_gs').indexOf(brand)>=0){
$(this).addClass('active');	
}
});
if(!$(this).hasClass('active')){
$('.sweech_gs>span').removeClass('active');
$(this).addClass('active');
}
});
});
$('.brands:not(.services)  .img').each(function(){
$(this).click(function(){
if(!$(this).hasClass('click')){
$('.brands:not(.services)  .img').removeClass('click');
$(this).addClass('click');
}
});
});
$('.akcse').each(function(){
$(this).click(function(){
if(!$(this).hasClass('active')){
$('.akcse').removeClass('active');
$(this).addClass('active');
}
});
});
$('.tarifs select').change(function(){
	var lks=0;
$('.zakas_tarif span,.zakzlk span,.whitefon b span').text('«'+$('.select select option:selected').text()+'»');	
var sect=$(this);
$('.akcse').removeClass('click');
$('.akcse').removeClass('active');
$('.akcse').each(function(){
if($(this).attr('tarif').indexOf(sect.val())>=0){
	lks++;
	if(lks==1){
$(this).addClass('active');
	}
$(this).addClass('click');
}
});
lks=0;
});
$('.zakas_tarif').click(function(){
$('.blackfon,.whitefon').show();
});
$('.blackfon,.close').click(function(){
$('.blackfon,.whitefon').removeAttr('style');
});
$('.services .img').each(function(){
$(this).click(function(){
console.log('Я кликнул');
if(!$(this).hasClass('click')){
$(this).addClass('click');
}else{
$(this).removeClass('click');
}
});
});
$('.zakas_tarif span,.zakzlk span,.whitefon b span').text('«'+$('.select select option:selected').text()+'»');
var obrn='';
$('#obrn').click(function(){
if ($(this).is(":checked")) {
obrn=$(this).val();
} else {
obrn='';
}

});
$('#ftarifz').submit(function(e){
e.preventDefault();
var dop_services;
var ins_serv=0;
$('.services .click').each(function(){
ins_serv++;
if(ins_serv==1){
dop_services=$(this).find('span').text();
}else if(ins_serv>1){
dop_services+=', '+$(this).find('span').text()
}
});
$.ajax({
url:     '../ajax.php',
type:     "POST",
dataType: "html",
data: {inn:$('.inn').val(),phone:$('.phone').val(),email:$('.email').val(),obrn:obrn,region:$('#region option:selected').text(),tonn:$('.tonn').text(),fuel:$('.sweech_gs .active').text(),brend:$('.brands:not(.services) .click span').text(),dop_services:dop_services,tarif:$('.select select option:selected').text(),promakcc:$('.akcse.click.active').text()}, 
success: function(response) {
$('.result').html(response);
},
error: function(response) {
$('.result').html('<p>Ошибка!</p>');
}
});
});
$(".phone").mask("+7-999-999-99-99");
$(".phone").click(function(){
$(this).setCursorPosition(3);
});
});